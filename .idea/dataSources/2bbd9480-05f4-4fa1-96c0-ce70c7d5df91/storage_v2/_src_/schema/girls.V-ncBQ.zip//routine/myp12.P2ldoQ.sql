create
    definer = root@localhost procedure myp12(IN mydate datetime, OUT strDate varchar(50))
begin
    select date_format(mydate,'yyyy-mm-dd' ) into strDate;
end;

