create
    definer = root@localhost procedure myp13(IN mydate datetime, OUT strDate varchar(50))
begin
    select date_format(mydate,'%y年%m月%d日' ) into strDate;
end;

