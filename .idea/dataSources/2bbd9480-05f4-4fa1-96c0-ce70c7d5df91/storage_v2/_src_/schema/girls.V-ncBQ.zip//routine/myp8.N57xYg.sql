create
    definer = root@localhost procedure myp8(INOUT a int, INOUT b int)
begin
    set a=a*2;
    set b=b*2;
end;

