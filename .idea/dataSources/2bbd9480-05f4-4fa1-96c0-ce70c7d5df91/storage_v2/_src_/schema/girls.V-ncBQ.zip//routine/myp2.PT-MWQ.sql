create
    definer = root@localhost procedure myp2(IN beautyName varchar(20))
begin
    select bo.* from boys bo right join beauty b on bo.id=b.boyfriend_id;
end;

