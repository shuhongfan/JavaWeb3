create
    definer = root@localhost procedure myp3(IN username varchar(20), IN password varchar(20))
begin
    declare result varchar(20) default '';

    select count(*) into result from admin where admin.username=username
    and admin.password=password;

    select result;
end;

