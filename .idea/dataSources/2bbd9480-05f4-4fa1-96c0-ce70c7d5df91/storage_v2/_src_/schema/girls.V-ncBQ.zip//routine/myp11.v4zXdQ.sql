create
    definer = root@localhost procedure myp11(IN b1 datetime, IN b2 datetime, OUT result int)
begin
    select datediff(b1,b2) into result;
end;

