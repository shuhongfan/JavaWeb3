create
    definer = root@localhost procedure pro_while(IN insertCount int)
begin
    declare i int default 1;
    while i<=insertCount do
    insert into admin(username, password) VALUES (concat('Rose',i),'6666');
    set i=i+1;
    end while;
end;

