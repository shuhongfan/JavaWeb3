create
    definer = root@localhost procedure myp6(IN beautyName varchar(20), OUT boyName varchar(20))
begin
    select bo.boyName from boys bo inner join beauty b on bo.id=b.boyfriend_id
    where b.name=beautyName;
end;

