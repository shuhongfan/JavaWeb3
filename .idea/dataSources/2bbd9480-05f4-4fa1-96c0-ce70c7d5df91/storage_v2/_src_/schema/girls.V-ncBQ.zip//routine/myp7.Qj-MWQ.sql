create
    definer = root@localhost procedure myp7(IN beautyname varchar(20), OUT boyName varchar(20), OUT userCP int)
begin
    select bo.boyName,bo.userCP into boyName,userCP
    from boys bo inner join beauty b on bo.id=b.boyfriend_id
    where b.name=beautyName;
end;

