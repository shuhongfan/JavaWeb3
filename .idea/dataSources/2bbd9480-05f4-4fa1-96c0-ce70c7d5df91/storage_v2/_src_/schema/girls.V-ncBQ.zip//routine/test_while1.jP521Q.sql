create
    definer = root@localhost procedure test_while1(IN insertCount int)
begin
    declare i int default 0;
    a:while i<=insertCount do
        set i=i+1;
        insert into admin(username, password) values (concat('xiaohua',i),'0000');
        if i>=20 then leave a; end if;
        if mod(i,2)!=0 then iterate a; end if;
        end while a;
end;

