create
    definer = root@localhost procedure myp14(IN name varchar(20), OUT result varchar(20))
begin
    select concat(name,' and ',ifnull(b.boyName,'null')) into result
        from beauty be left join boys b on be.boyfriend_id=b.id
    where be.name=name;
end;

