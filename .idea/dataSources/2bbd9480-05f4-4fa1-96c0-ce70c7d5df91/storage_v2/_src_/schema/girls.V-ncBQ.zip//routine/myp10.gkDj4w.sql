create
    definer = root@localhost procedure myp10(IN id int, OUT name varchar(20), OUT phone varchar(20))
begin
    select b.name,b.phone into name,phone
    from beauty b where b.id=id;
end;

