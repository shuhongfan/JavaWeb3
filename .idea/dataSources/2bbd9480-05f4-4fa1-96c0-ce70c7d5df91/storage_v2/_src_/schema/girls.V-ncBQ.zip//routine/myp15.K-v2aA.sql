create
    definer = root@localhost procedure myp15(IN startIndex int, IN size int)
begin
    select * from beauty limit startIndex,size;
end;

