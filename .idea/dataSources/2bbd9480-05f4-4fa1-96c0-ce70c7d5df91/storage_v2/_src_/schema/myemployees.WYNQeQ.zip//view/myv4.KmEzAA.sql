create view myv4 as
select avg(`myemployees`.`employees`.`salary`)   AS `avg(salary)`,
       `myemployees`.`employees`.`department_id` AS `department_id`
from `myemployees`.`employees`
group by `myemployees`.`employees`.`department_id`;

