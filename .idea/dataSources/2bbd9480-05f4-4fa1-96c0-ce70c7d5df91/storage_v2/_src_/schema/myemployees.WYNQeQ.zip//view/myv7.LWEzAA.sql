create view myv7 as
select (select max(`myemployees`.`employees`.`salary`) from `myemployees`.`employees`) AS `最高工资`;

