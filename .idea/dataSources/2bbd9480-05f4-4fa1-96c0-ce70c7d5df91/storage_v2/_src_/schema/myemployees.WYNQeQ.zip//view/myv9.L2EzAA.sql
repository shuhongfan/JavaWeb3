create view myv9 as
select `myv3`.`ag` AS `ag`, `myv3`.`department_id` AS `department_id`
from `myemployees`.`myv3`;

