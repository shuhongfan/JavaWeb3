create view myv8 as
select `e`.`last_name` AS `last_name`, `d`.`department_name` AS `department_name`
from (`myemployees`.`employees` `e`
         join `myemployees`.`departments` `d` on ((`d`.`department_id` = `e`.`department_id`)));

