create view myv6 as
select 'john' AS `name`;

