create view emp_v2 as
select max(`e`.`salary`) AS `m`, `d`.`department_id` AS `department_id`, `d`.`department_name` AS `department_name`
from (`myemployees`.`employees` `e`
         left join `myemployees`.`departments` `d` on ((`d`.`department_id` = `e`.`department_id`)))
group by `d`.`department_id`
having (`m` > 12000);

