create view myvl as
select `test`.`book`.`bname` AS `bname`, `test`.`book`.`price` AS `price`
from `test`.`book`
where ((`test`.`book`.`price` >= 90) and (`test`.`book`.`price` <= 120));

